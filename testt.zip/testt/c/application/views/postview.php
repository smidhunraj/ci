
<!DOCTYPE html>
<head>
</head>

<body>
    <h2>Search In CodeIgniter- php framework</h2>
    <form action="<?php echo site_url('post/skeyword'); ?>" method="post">
        <input type="text" name="title">
        <input type="submit" name="submit" value="Search">
    </form-->

</body>
</html>

