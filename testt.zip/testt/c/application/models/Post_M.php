<?php
defined('BASEPATH') OR exit('No direct script access allowed');


/**
* 
*/
class Post_M extends CI_Model
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function search($key)
    {
        $this->db->like('title', $key);
        $query = $this->db->get('posts');
        return $query->result();
    }
}

